// $Id$


function annotation_node( container, an_id) {
	$(container).before("<div id='annotation-node-dragger-" + an_id + "' class='annotation-node-dragger active'></div>");
	var dragger = $("div#annotation-node-dragger-" + an_id);
	dragger.prepend("<div id='annotation-node-dragger-trigger_" + an_id + "'><div>");
	dragger.prepend("<div class='dragger_knob'></div>");
	var knob = $("div#annotation-node-dragger-" + an_id + " div.dragger_knob");
	var trigger = $("div#annotation-node-dragger-trigger_" + an_id);	
	trigger.addClass('annotation-node-trigger');
  dragger.draggable({ cursorAt: { left: 5 }, handle: 'div.dragger_knob', containment: container, opacity: 0.3 });
	// AFTER DRAGG
	dragger.bind('dragstop', function(event, ui) {
		var t = ui.offset.top - $(container).offset().top;
		var l = ui.offset.left - $(container).offset().left;
		var w = ui.helper.width();
		var h = ui.helper.height();
		var cw = $(container).width();
		var ch = $(container).height();
		var positions = { top:t, left:l , width:w, height:h, container_w:cw, container_h:ch };
		var pos = t + "-" + l + "-" + w + "-" + h + "-" + cw + "-" + ch;
		var url = "";
		// Get trigger with variables
		$.post(
		  Drupal.settings.basePath + '?q=annotation_node/trigger/' + an_id,
		  {q: 'annotation_node/trigger/' + an_id, position: pos},
		  function (data) {trigger.html(data);},
		  'html'
    );	 
  });
}
