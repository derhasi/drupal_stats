# $Id$

This module was intended to proof some concepts for content annotation. It's
aimed to join the annotation.module, but this will need additional discussion
on concepts an merging other modules.


## hook_MENU ##

provides a AJAX callback that will retrieve